import 'package:flutter/material.dart';
import 'barcode_scanner.dart';
import '../data/db_helper.dart';
class AddItemSheet extends StatefulWidget {
  final Function(Map<String, dynamic> item) onSave;

  const AddItemSheet({super.key, required this.onSave});

  @override
  State<AddItemSheet> createState() => _AddItemSheetState();
}

class _AddItemSheetState extends State<AddItemSheet> {
  final nameController = TextEditingController();
  final qtyController = TextEditingController();
  final categoryController = TextEditingController();
  final barcodeController = TextEditingController();
  final costController = TextEditingController();
  final sellingController = TextEditingController();

  void submit() {
    final item = {
      "name": nameController.text.trim(),
      "quantity": int.tryParse(qtyController.text) ?? 0,
      "category": categoryController.text.trim().isEmpty
          ? "General"
          : categoryController.text.trim(),
      "barcode": barcodeController.text.trim().isEmpty
          ? null
          : barcodeController.text,
      "costPrice": costController.text.isEmpty
          ? null
          : double.tryParse(costController.text),
      "sellingPrice": sellingController.text.isEmpty
          ? null
          : double.tryParse(sellingController.text),
      "createdAt": DateTime.now().toIso8601String(),
    };

    widget.onSave(item);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Add Item",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 12),

            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: "Item Name"),
            ),

            TextField(
              controller: barcodeController,
              decoration: const InputDecoration(
                labelText: "Barcode (optional)",
              ),
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text("Scan Barcode"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BarcodeScanner(
                      onDetect: (code) async {
                        final existingItem = await DBHelper.getByBarcode(code);

                        if (existingItem != null) {
                          // CASE 1: ITEM EXISTS → update stock
                          final updatedQty = existingItem.quantity + 1;

                          await DBHelper.updateQuantity(
                            existingItem.id!,
                            updatedQty,
                          );

                          Navigator.pop(context);
                        } else {
                          // CASE 2: NEW ITEM → just fill form
                          setState(() {
                            barcodeController.text = code;
                          });

                          Navigator.pop(context);
                        }
                      },
                    ),
                  ),
                );
              },
            ),
            TextField(
              controller: qtyController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Quantity"),
            ),

            TextField(
              controller: categoryController,
              decoration: const InputDecoration(labelText: "Category"),
            ),

            TextField(
              controller: costController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Cost Price"),
            ),

            TextField(
              controller: sellingController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Selling Price"),
            ),

            const SizedBox(height: 16),

            ElevatedButton(onPressed: submit, child: const Text("Save Item")),
          ],
        ),
      ),
    );
  }
}
